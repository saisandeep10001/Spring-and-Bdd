package com.cg.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.IEmployeeService;


@RestController
public class EmployeeController {
	@Autowired
	private IEmployeeService employeeService;
	
	
	//Insert Employee
	@RequestMapping(value = "create", method = RequestMethod.POST)
	public String create( @RequestBody Employee employee) throws EmployeeException {
		 employeeService.create(employee);
		 return "Employee inserted";
	}
	
	
	//Update Employee
	@RequestMapping(value = "/updateemployee", method = RequestMethod.PUT)
	public Employee update(@RequestBody Employee employee){
		return employeeService.update(employee);
	}
	
	//Delete Employee
	@RequestMapping(value="/deleteemployee/{id}", method=RequestMethod.DELETE)
	public String delete(@PathVariable Integer id) throws EmployeeException {
		employeeService.delete(id);
		return id+" is deleted";
	}
	
	
	//view Employees
	@RequestMapping(value="/employees", method=RequestMethod.GET)
	public List<Employee> view() throws EmployeeException {
		return employeeService.view();
		
	}
	
	
	//Get by Employee Id
	@RequestMapping(value = "/getbyid?Id={Id}", method = RequestMethod.GET)
	public Employee viewById(@PathVariable("Id") Integer id){
		return employeeService.find(id);
	}
	
	
	//Get By Employee Department
	@RequestMapping(value = "/employees/{gender}", method = RequestMethod.GET)
	public List<Employee> viewByDept(@PathVariable("gender")String gender) {
		return employeeService.viewByDept(gender);
	}
}
