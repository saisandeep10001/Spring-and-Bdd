package com.cg.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.dao.IEmployeeRepo;
import com.cg.exception.EmployeeException;
import com.cg.exception.ExceptionMessages;


@Service
public class EmployeeServiceImpl implements IEmployeeService{
	
	@Autowired
	private IEmployeeRepo employeeRepo;
	
	//Insert Employee
	@Override
	public void create(Employee employee) throws EmployeeException {
		try {
			employeeRepo.save(employee);
		}
		catch (Exception e) {
			throw new EmployeeException(ExceptionMessages.MESSAGE1); 
		}
	}

	
	//View Employeess
	@Override
	public List<Employee> view() throws EmployeeException {
		try {
		return employeeRepo.findAll();
		}
		catch (Exception e) {
			throw new EmployeeException(ExceptionMessages.MESSAGE2); 
		}
	}

	
	//Update Employee
	@Override
	public Employee update(Employee employee) {
		Optional<Employee> employee1 = employeeRepo.findById(employee.getId());
		Employee updateEmp=employee1.get();
		updateEmp.setName(employee.getName());

		updateEmp.setGender(employee.getGender());
		updateEmp.setSalary(employee.getSalary());
		employeeRepo.save(updateEmp);
		return updateEmp;
	}

	
	
	//Delete Employee
	@Override
	public void delete(Integer id) throws EmployeeException {
		Optional<Employee> employee = employeeRepo.findById(id);
		if(employee.isPresent())
        {
			employeeRepo.deleteById(id);

        } else {
            throw new EmployeeException(ExceptionMessages.MESSAGE3);
        }
	}

	
	
	//Get Employee By Id
	@Override
	public Employee find(Integer id) {
		return employeeRepo.findById(id).get();
	}

	
	//Get Employee By Department
	@Override
	public List<Employee> viewByDept(String gender)  {
		List<Employee> result=new ArrayList<Employee>();
		List<Employee> e=employeeRepo.findAll();
		for (Employee employee2 : e) {
			if(employee2.getGender().equals(gender)) {
				result.add(employee2);
			}
		}
		return result;
	}

}
