package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;

//Employee Service Interface
public interface IEmployeeService {
	void create(Employee employee) throws EmployeeException;
	
	List<Employee> view() throws EmployeeException;
	
	Employee update(Employee employee);
	
	void delete(Integer id) throws EmployeeException;
	
	Employee find(Integer id);
	
	List<Employee> viewByDept(String gender);
}
