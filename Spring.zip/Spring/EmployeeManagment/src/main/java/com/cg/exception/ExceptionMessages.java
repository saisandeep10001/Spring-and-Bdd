package com.cg.exception;

public interface ExceptionMessages {
	String MESSAGE1="data not saved due to internal error";
	String MESSAGE2="no data to view";
	String MESSAGE3="Employee Id not available";
	String MESSAGE4 = "invalid department";
}
