package com.cg.ses.controller;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ses.bean.Session;
import com.cg.ses.exception.SessionException;
import com.cg.ses.service.SessionService;

@RestController
public class SessionController {
	@Autowired
	SessionService sessionService;
	@RequestMapping("/ViewAllSession")
	  public List<Session> getSessions() throws SessionException {
      return sessionService.getAllSessions();
	}
	@PostMapping(value="/AddSession")
	public List<Session> addSession(@RequestBody Session sess)throws SessionException{
	return sessionService.addSession(sess);
	}
	 
	 @DeleteMapping("/DeleteSession/{id}")
		public List<Session> deleteSession(@PathVariable int id)throws SessionException{
			return sessionService.deleteSession(id);
		}
	@PutMapping("/UpdateSession/{id}")
	public List<Session> updateSession(@PathVariable int id,@RequestBody Session sess)throws SessionException{
		return sessionService.updateSession(id, sess);
		
	}
	@ExceptionHandler({SessionException.class})
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<String>("An Error Occurred "+ex.getMessage(),HttpStatus.CONFLICT);
	}
}
