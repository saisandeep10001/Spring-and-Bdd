package com.cg.ses;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionManagement185874Application {

	public static void main(String[] args) {
		SpringApplication.run(SessionManagement185874Application.class, args);
	}

}
