package com.cg.ses.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ses.bean.Session;
import com.cg.ses.dao.SessionDao;
import com.cg.ses.exception.SessionException;
@Service
public class SessionServiceImpl implements SessionService {
	@Autowired
	SessionDao sessionDao;
	
	
	/***
	 * Author: Sai Sandeep Chandana
	 * Date Of Creation: 30-07-2019
	 * Method: Add Session
	 * Parameters: Parameter of type Scheduled Session Management
	 * Return Value: Return data of session
	 * Purpose: Adding the data in session 
	 */
	@Override
	public List<Session> addSession(Session sess) throws SessionException {
		try {
			sessionDao.save(sess);
			return sessionDao.findAll();
			}
			catch(Exception ex) {
				throw new SessionException(ex.getMessage());
			}
	}

	
	/***
	 * Author: Sai Sandeep Chandana
	 * Date Of Creation: 30-07-2019
	 * Method: Getting All Session
	 * Parameters: Parameter of type Scheduled Session Management
	 * Return Value: Return data of session
	 * Purpose: Getting all the data in session 
	 */
	@Override
	public List<Session> getAllSessions() throws SessionException {
		try
		{
		return sessionDao.findAll();
		}
		catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
	}

	
	/***
	 * Author: Sai Sandeep Chandana
	 * Date Of Creation: 30-07-2019
	 * Method: Delete Session
	 * Parameters: Parameter of type Scheduled Session Management
	 * Return Value: Return data of session
	 * Purpose: Delete elements in session 
	 */
	@Override
	public List<Session> deleteSession(int id) throws SessionException {
		try {
			sessionDao.deleteById(id);
			return getAllSessions();
			}
			catch(Exception e) {
				throw new SessionException(e.getMessage());
			}
	}

	
	/***
	 * Author: Sai Sandeep Chandana
	 * Date Of Creation: 30-07-2019
	 * Method: Update Session
	 * Parameters: Parameter of type Scheduled Session Management
	 * Return Value: Return data of session
	 * Purpose: Update elements in session like duration and faculty name using session id in database 
	 */
	@Override
	public List<Session> updateSession(int id, Session sess) throws SessionException {
		try
        {
            Optional<Session> optional=sessionDao.findById(id);
            if(optional.isPresent())
            {
                Session session=optional.get();
                session.setDuration(sess.getDuration());
                session.setFaculty(sess.getFaculty());
                sessionDao.save(session);
                return getAllSessions();
            }
            else {
            	throw new SessionException("Sessionn With Id "+id+" does not exist");
            }
	
        }
		catch(Exception e) {
			throw new SessionException("Given Invalid details!!");
		}
	}
}


