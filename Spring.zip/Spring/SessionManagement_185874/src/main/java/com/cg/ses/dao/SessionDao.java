package com.cg.ses.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.ses.bean.Session;

public interface SessionDao extends JpaRepository<Session, Integer> {

}
