package com.cg.ses.service;

import java.util.List;
import com.cg.ses.bean.Session;
import com.cg.ses.exception.SessionException;

public interface SessionService {
	public List<Session> addSession(Session sess)throws SessionException;
	
	public List<Session> getAllSessions() throws SessionException;
	public List<Session> deleteSession(int id) throws SessionException;
	public List<Session> updateSession(int id,Session sess) throws SessionException;
}
