package com.cg.sampl.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.cg.sampl.bean.Sessio;

@Repository
public interface IsessionDao extends JpaRepository<Sessio, Integer> {

}
