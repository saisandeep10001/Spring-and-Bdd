package com.cg.sampl.exception;
public class ExceptionMessage {

	public static final String Message1 = "Invaid data";

}
