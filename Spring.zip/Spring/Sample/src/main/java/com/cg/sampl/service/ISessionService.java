package com.cg.sampl.service;

import java.util.List;

import com.cg.sampl.bean.Sessio;
import com.cg.sampl.exception.SessionExceptions;

public interface ISessionService {

	List<Sessio> addSession(Sessio session) throws SessionExceptions ;
	
	List<Sessio> viewAllSessions() throws SessionExceptions;
	
	void deleteSession(Integer id);
	
	Sessio updateDuration(Integer id,Integer duration);
	
	Sessio updateFaculty(Integer id,String faculty);
	
}

