package com.cg.sampl.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.sampl.bean.Sessio;
import com.cg.sampl.exception.SessionExceptions;
import com.cg.sampl.service.ISessionService;

@RestController
public class SessionController {
	@Autowired
	private ISessionService service;
	

	@RequestMapping(value = "/addSession",method = RequestMethod.POST)
	public List<Sessio> addSession(@RequestBody Sessio session) throws SessionExceptions 
	{
		
			return service.addSession(session);
	
	}

	@RequestMapping(value = "/viewAll",method = RequestMethod.GET)
	public List<Sessio> viewAllSessions() throws SessionExceptions{
		return service.viewAllSessions();
	}
	
	@RequestMapping(value = "/delete/{id}",method = RequestMethod.DELETE)
	public String deleteSession(@PathVariable("id") Integer id) {
		service.deleteSession(id);
		return id+" is deleted sucessfully";
		
	}

	@RequestMapping(value = "/updateDuration/{id}/{duration}")
	public Sessio update(@PathVariable("id") Integer id,@PathVariable("duration") Integer duration) {
		return service.updateDuration(id, duration);
	}

	@RequestMapping(value = "/updateFaculty/{id}/{faculty}")
	public Sessio update(@PathVariable("id") Integer id,@PathVariable("faculty") String faculty) {
		return service.updateFaculty(id, faculty);
	}
	
	
	

}
