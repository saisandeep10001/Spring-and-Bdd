package com.cg.sampl.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sampl.bean.Sessio;
import com.cg.sampl.dao.IsessionDao;
import com.cg.sampl.exception.ExceptionMessage;
import com.cg.sampl.exception.SessionExceptions;

@Service
public class SessionServiceImpl implements ISessionService{
	
	@Autowired
	private IsessionDao repo;

	@Override
	public List<Sessio> addSession(Sessio session) throws SessionExceptions {
		if(session.getDuration()>3 && (session.getMode().equalsIgnoreCase("ilt") || session.getMode().equalsIgnoreCase("vc")))
		{
			try {
		
		 repo.save(session);
		}
		catch(Exception exception)
		{
			throw new SessionExceptions(ExceptionMessage.Message1);
		}
		}
		return repo.findAll();
	}

	@Override
	public List<Sessio> viewAllSessions() throws SessionExceptions {
		
		return repo.findAll();
	}
	
	@Override
	public void deleteSession(Integer id)  {
		repo.deleteById(id);
		
	}
	
	@Override
	public Sessio updateDuration(Integer id, Integer duration) {
		Sessio session= repo.findById(id).get();
		session.setDuration(duration);
		repo.save(session);
		return repo.findById(id).get();
	}
	
	@Override
	public Sessio updateFaculty(Integer id, String faculty) {
		Sessio session= repo.findById(id).get();
		session.setFaculty(faculty);
		repo.save(session);
		return repo.findById(id).get();
	}

}
