package com.cg.cust.service;

import java.util.List;

import com.cg.cust.bean.Parallel;
import com.cg.cust.exception.ParallelException;

public interface ParallelService {
	public List<Parallel> addParallel(Parallel cust)throws ParallelException;
	public Parallel getParallelByAccountno(int accountno) throws ParallelException;
	public List<Parallel> getAllParallels() throws ParallelException;
	public void updateParallel(Parallel cust) throws ParallelException;


}
	
