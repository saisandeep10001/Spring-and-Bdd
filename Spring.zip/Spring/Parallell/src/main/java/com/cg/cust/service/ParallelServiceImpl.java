package com.cg.cust.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cust.bean.Parallel;
import com.cg.cust.dao.ParallelDao;
import com.cg.cust.exception.ParallelException;

@Service
public class ParallelServiceImpl implements ParallelService {
	
	@Autowired
	ParallelDao parallelDao;
	@Override
	public List<Parallel> addParallel(Parallel cust) throws ParallelException {

		// TODO Auto-generated method stub
		try {
		parallelDao.save(cust);
		return parallelDao.findAll();
		}
		catch(Exception ex) {
			throw new ParallelException(ex.getMessage());
		}
	}

	@Override
	public Parallel getParallelByAccountno(int accountno) throws ParallelException {
		// TODO Auto-generated method stub
		try {
			
			return parallelDao.findById(accountno).get();
			}
			catch(Exception ex) {
				throw new ParallelException(ex.getMessage());
			}
	}

	@Override
	public List<Parallel> getAllParallels() throws ParallelException {
		// TODO Auto-generated method stub
		try
			{
			return parallelDao.findAll();
			}
			catch(Exception e) {
				throw new ParallelException(e.getMessage());
			}
	}

	@Override
	public void updateParallel(Parallel cust) throws ParallelException {
		// TODO Auto-generated method stub
		  parallelDao.save(cust);
	}


	
}
