package com.cg.cust.exception;

public class ParallelException extends Exception {
	public ParallelException() {
		super();
	}
	public ParallelException(String msg) {
		super(msg);
	}
}
