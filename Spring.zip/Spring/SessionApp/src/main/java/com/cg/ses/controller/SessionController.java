package com.cg.ses.controller;

import java.util.List;




import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ses.bean.Sessionn;
import com.cg.ses.exception.SessionException;
import com.cg.ses.service.SessionService;

@RestController
public class SessionController {
	@Autowired
	SessionService sessionService;
	@RequestMapping("/sessions")
	  public List<Sessionn> getSessions() throws SessionException {
      return sessionService.getAllSessions();
	}
	@RequestMapping(value="/sessions",method=RequestMethod.POST)
	public List<Sessionn> addSession(@RequestBody Sessionn sess)throws SessionException{
	return sessionService.addSession(sess);
	}
	 @RequestMapping("/sessions/{id}")
     public Sessionn getSessionById(@PathVariable int id) throws SessionException{
             return sessionService.getSessionById(id);
     }
	 @RequestMapping(value="/getSessionByfaculty/{faculty}")
		public List<Sessionn> findSessionsByfaculty(@PathVariable String faculty) throws SessionException{
			return sessionService.getSessionsByfaculty(faculty);
		}
	@DeleteMapping("/sessions/{id}")
		public ResponseEntity<String> deleteSession(@PathVariable int id)throws SessionException{
			sessionService.deleteSession(id);
			return new ResponseEntity<String>("Sessionn with id "+id+" deleted",HttpStatus.OK);
	}
	@PutMapping("/sessions/{id}")
	public List<Sessionn> updateSession(@PathVariable int id,@RequestBody Sessionn sess)throws SessionException{
		return sessionService.updateSession(id, sess);
		
	}
	@ExceptionHandler({SessionException.class})
	public ResponseEntity<String> handleErrors(Exception ex){
		return new ResponseEntity<String>("An Error Occurred"+ex.getMessage(),HttpStatus.CONFLICT);
	}
}
