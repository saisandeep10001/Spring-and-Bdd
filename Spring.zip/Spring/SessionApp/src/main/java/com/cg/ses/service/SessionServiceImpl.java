package com.cg.ses.service;

import java.util.List;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ses.bean.Sessionn;
import com.cg.ses.dao.SessionDao;
import com.cg.ses.exception.SessionException;

@Service
public class SessionServiceImpl implements SessionService {

	@Autowired
	SessionDao sessionDao;
	@Override
	public List<Sessionn> addSession(Sessionn sess) throws SessionException {
		// TODO Auto-generated method stub
		try {
			sessionDao.save(sess);
			return sessionDao.findAll();
			}
			catch(Exception ex) {
				throw new SessionException(ex.getMessage());
			}
		}

	@Override
	public Sessionn getSessionById(int id) throws SessionException {
		// TODO Auto-generated method stub
		try {
			
			return sessionDao.findById(id).get();
			}
			catch(Exception ex) {
				throw new SessionException(ex.getMessage());
			}
	}
	
	@Override
	public void deleteSession(int id) throws SessionException {
		// TODO Auto-generated method stub
		try {
			sessionDao.deleteById(id);
			}
			catch(Exception e) {
				throw new SessionException(e.getMessage());
			}
	}

	@Override
	public List<Sessionn> getAllSessions() throws SessionException {
		// TODO Auto-generated method stub
		try
		{
		return sessionDao.findAll();
		}
		catch(Exception e) {
			throw new SessionException(e.getMessage());
		}
}

	@Override
	public List<Sessionn> getSessionsByfaculty(String faculty) throws SessionException {
		// TODO Auto-generated method stub
		try {
			 List<Sessionn> sessions=sessionDao.getSessionByFaculty(faculty);
	            if(sessions.size()==0) {
	                throw new SessionException("Invalid faculty Name");
	            }
	            else {
	                return sessions;
	            }
			//return sessionDao.getSessionByFaculty(faculty);
			}
			catch(Exception e) {
				throw new SessionException(e.getMessage());
			}

	}

	@Override
	public List<Sessionn> updateSession(int id, Sessionn sess) throws SessionException {
		// TODO Auto-generated method stub
		try
        {
            Optional<Sessionn> optional=sessionDao.findById(id);
            if(optional.isPresent())
            {
                Sessionn session=optional.get();
                session.setModel(sess.getModel());
                session.setFaculty(sess.getFaculty());
                sessionDao.save(session);
                return getAllSessions();
            }
            else {
            	throw new SessionException("Sessionn With Id "+id+"does not exist");
            }
	
	}
	catch(Exception e) {
		throw new SessionException(e.getMessage());
	}
}

}
