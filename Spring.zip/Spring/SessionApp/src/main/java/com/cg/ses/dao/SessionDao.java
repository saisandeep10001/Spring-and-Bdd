package com.cg.ses.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.ses.bean.Sessionn;

public interface SessionDao extends JpaRepository<Sessionn, Integer> {
	@Query("from Sessionn where faculty=:f")
	List<Sessionn> getSessionByFaculty(@Param("f") String faculty);
}
