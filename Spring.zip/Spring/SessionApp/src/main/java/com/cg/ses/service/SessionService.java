package com.cg.ses.service;

import java.util.List;

import com.cg.ses.bean.Sessionn;
import com.cg.ses.exception.SessionException;


public interface SessionService {
	public List<Sessionn> addSession(Sessionn sess)throws SessionException;
	public Sessionn getSessionById(int id) throws SessionException;
	public List<Sessionn> deleteSession(int id) throws SessionException;
	public List<Sessionn> getAllSessions() throws SessionException;
	public List<Sessionn> getSessionsByfaculty(String faculty) throws SessionException;
	public List<Sessionn> updateSession(int id,Sessionn sess) throws SessionException;
}
