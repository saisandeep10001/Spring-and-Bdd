package com.cg.cust.exception;

public class CustomerException extends Exception {
	public CustomerException() {
		super();
	}
	public CustomerException(String msg) {
		super(msg);
	}
}
