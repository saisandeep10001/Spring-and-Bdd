package com.cg.prodapp.service;

import java.util.List;
import com.cg.prodapp.bean.Product;

public interface ProductService {
    List<Product> getAllEmployees();
    Product getEmployeeById(int id);
    void updateProduct(Product pro);
    void addProduct(Product pro);
    void deleteProduct(int id);
    List<Product> getProductByPrice(double miniPrice,double maxPrice);
    public boolean doValidation(String cate, int qty);
}
 





