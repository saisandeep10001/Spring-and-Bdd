package com.cg.prodapp.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.prodapp.bean.Product;
import com.cg.prodapp.dao.ProductDao;

@Service
public class ProductServiceImpl implements ProductService  {
    @Autowired
    ProductDao productDao;
    @Override
    public List<Product> getAllEmployees() {
        // TODO Auto-generated method stub
        return productDao.findAll();
    }


    @Override
    public Product getEmployeeById(int id) {
        // TODO Auto-generated method stub
        return productDao.findById(id).get();
    }
    @Override
    public void updateProduct(Product pro) {
        // TODO Auto-generated method stub
        productDao.save(pro);
    }

 

    @Override
    public void addProduct(Product pro) {
        // TODO Auto-generated method stub
        productDao.save(pro);
    }
    @Override
    public void deleteProduct(int id) {
        // TODO Auto-generated method stub
        productDao.deleteById(id);
    }

 

    @Override
    public List<Product> getProductByPrice(double miniPrice, double maxPrice) {
        // TODO Auto-generated method stub
        return productDao.getProductByPrice(miniPrice, maxPrice);
    }

 

    @Override
    public boolean doValidation(String cate, int qty) {
         if((cate.equals("phone") ||cate.equals("tv") ||cate.equals("laptop")) && qty>0)
                return true;
            else
        return false;
    }

}