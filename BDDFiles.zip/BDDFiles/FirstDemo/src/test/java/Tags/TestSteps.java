package Tags;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;

public class TestSteps {
	@Given("^This is a blank test$")
	public void this_is_a_blank_test() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
    throw new PendingException();
	}
	@Before
    public void beforeScenario() {
        System.out.println("THIS WILL RUN BEFORE");
    }
    @After
    public void afterScenario() {
        System.out.println("THIS WILL RUN AFTER");
    }
}
