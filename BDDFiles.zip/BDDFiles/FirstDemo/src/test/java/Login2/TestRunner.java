package Login2;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features="src/main/resources/Login2/Login2.feature",glue="Login2",plugin="pretty")
public class TestRunner {

}
