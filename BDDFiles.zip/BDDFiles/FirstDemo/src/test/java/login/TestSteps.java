package login;

import static org.junit.Assert.assertEquals;

import com.cg.bdd.User;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class TestSteps {
	@Given("^User is on Home page$")
	public void user_is_on_Home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@Given("^Login link is available$")
	public void login_link_is_available() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}
	User user1=new User();
	@When("^user enters user name and password$")
	public void user_enters_user_name_and_password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		user1.setUsername("SaiSandeep");
		user1.setPassword("sandeep@1001");
		
//	    throw new PendingException();
	}

	@When("^if entered credentials are correct$")
	public void if_entered_credentials_are_correct() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		assertEquals(user1.getUsername(),"SaiSandeep");
		assertEquals(user1.getPassword(),"sandeep@1001");
//	    throw new PendingException();
	}

	@Then("^Display message as 'successful Login'$")
	public void display_message_as_successful_Login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@When("^entered credentials are wrong$")
	public void entered_credentials_are_wrong() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}

	@Then("^Display message as 'unsuccessful Login'$")
	public void display_message_as_unsuccessful_Login() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
//	    throw new PendingException();
	}


}
